import sys  # sys нужен для передачи argv в QApplication

from PyQt5 import sip
from PyQt5 import QtWidgets
import mydesign # Это наш конвертированный файл дизайна

from mydesign import *

from PyQt5.QtWidgets import QTableWidgetItem
from PyQt5.QtWidgets import QDialog, QApplication, QPushButton, QVBoxLayout
from PyQt5.QtWidgets import QTableWidget
from PyQt5.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QMessageBox

import random




class ExampleApp_a(QtWidgets.QMainWindow,  mydesign.Ui_MainWindow):
    def __init__(self):

        super().__init__()
        self.setupUi(self)

        # a figure instance to plot on

        self.btnAnalysis.clicked.connect(self.procces)

        # set the layout


    def procces(self,state):
        try:
            self.S = (self.startBalance.text())

            self.S = float(self.S)
            self.LC = (self.mont_zatrat.text())
            self.LC = - float(self.LC)
            self.OC = (self.zatrat_perevozka.text())
            self.OC = -float(self.OC)
            self.D = (self.month_spros.text())
            self.D = float(self.D)
            self.Y = (self.D * 12)
            self.Y = float(self.Y)
            print('Количество товара, необходимого на один год, равно ', self.Y)
            self.R = (self.cost_sur_for_.text())
            self.R = float(self.R)
            self.AL = -self.D * 12 * self.R  # -
            self.AL = float(self.AL)
            self.ALT = -self.D * 12 * self.R  # -
            self.ALT = float(self.ALT)
            print('Годовые затраты на сырье равны', self.AL)
            print('Мы возьмем кредит на цели предприятия на сумму $', self.AL)
            self.P = (self.cost_tovar.text())
            self.P = float(self.P)
            self.PM = self.D * self.P
            self.PM = float(self.PM)
            print('Вследствие этого, с тех пор как месячный спрос равен', self.D, 'месячный доход от продаж -', self.PM)
            self.ir = (self.procent_stavka.text())
            self.ir = float(self.ir)
            self.Z = (self.ir / 12)
            self.Z = float(self.Z)
            print('Таким образом, процентная ставка будет равна:', self.Z)
            self.QRS = (self.count_month.text())
            self.QRS = float(self.QRS)
            self.IF = (self.intRate.text())
            self.IF = float(self.IF)
            self.INF = self.IF / 12
            self.INF = float(self.INF)
            print(self.INF)
        except Exception:
            QtWidgets.QMessageBox.about(self, 'Error', 'Вводить можно только числа')
            pass

        #
        # колебания цен - 10%
        self.PM90 = self.PM * .9
        self.PM110 = self.PM * 1.1
        #
        # колебания по процентной ставке - 10%
        self.Z90 = self.Z * .9
        self.Z110 = self.Z * 1.1
        #
        # колебания на цены материала - 10%
        self.AL90 = self.AL * .9
        self.AL110 = self.AL * 1.1
        self.ALT90 = self.ALT * .9
        self.ALT110 = self.ALT * 1.1
        ##
        #
        # Колебания на спрос в 1%
        self.PP99 = self.PM * .99
        self.PP98 = self.PM * .98
        self.PP97 = self.PM * .97
        self.PP96 = self.PM * .96
        self.PP95 = self.PM * .95
        self.PP94 = self.PM * .94
        self.PP93 = self.PM * .93
        self.PP92 = self.PM * .92
        self.PP91 = self.PM * .91
        self.PP90 = self.PM * .9
        self.PP101 = self.PM * 1.01
        self.PP102 = self.PM * 1.02
        self.PP103 = self.PM * 1.03
        self.PP104 = self.PM * 1.04
        self.PP105 = self.PM * 1.05
        self.PP106 = self.PM * 1.06
        self.PP107 = self.PM * 1.07
        self.PP108 = self.PM * 1.08
        self.PP109 = self.PM * 1.09
        self.PP110 = self.PM * 1.1

        name_checkbox = self.stableForec.text()

        if name_checkbox == "Прогноз без колебаний" and self.stableForec.isChecked():

            print("---------------------------------------------------")
            ExampleApp_a.one(self)

        name_checkbox = self.InflForec.text()

        if name_checkbox == "Прогноз с учетом инфляции" and self.InflForec.isChecked():
            print("++++++++++++++++++++++++++++++++")
            ExampleApp_a.two(self)

        name_checkbox = self.priceInf.text()

        if name_checkbox == "c учетом разницы в цене в +10%" and self.priceInf.isChecked():
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`")
            ExampleApp_a.three(self)

        name_checkbox = self.stableForec_2.text()

        if name_checkbox == "c процентной ставки в +10%" and self.stableForec_2.isChecked():
            print("---------------------------------------------------")
            ExampleApp_a.four(self)

        name_checkbox = self.InflForec_2.text()

        if name_checkbox == "разницы на материалы в -10%" and self.InflForec_2.isChecked():
            print("++++++++++++++++++++++++++++++++")
            ExampleApp_a.five(self)

        name_checkbox = self.InflForec_3.text()

        if name_checkbox == "разницы на материалы в +10%" and self.InflForec_3.isChecked():
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`")
            ExampleApp_a.six(self)

        name_checkbox = self.InflForec_5.text()

        if name_checkbox == "-2%" and self.InflForec_5.isChecked():

            print("---------------------------------------------------")
            ExampleApp_a.ras(self,self.PP98)

        name_checkbox = self.InflForec_6.text()

        if name_checkbox == "-3%" and self.InflForec_6.isChecked():
            print("++++++++++++++++++++++++++++++++")
            ExampleApp_a.ras(self,self.PP97)

        name_checkbox = self.InflForec_7.text()

        if name_checkbox == "-4%" and self.InflForec_7.isChecked():
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`")
            ExampleApp_a.ras(self,self.PP96)

        name_checkbox = self.InflForec_4.text()

        if name_checkbox == "-1%" and self.InflForec_4.isChecked():
            print("---------------------------------------------------")
            ExampleApp_a.ras(self,self.PP91)

        name_checkbox = self.demandInfl_7.text()

        if name_checkbox == "-10%" and self.demandInfl_7.isChecked():
            print("++++++++++++++++++++++++++++++++")
            ExampleApp_a.ras(self,self.PP110)

        name_checkbox = self.demandInfl_3.text()

        if name_checkbox == "-7%" and self.demandInfl_3.isChecked():
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`")
            ExampleApp_a.ras(self,self.PP93)

        name_checkbox = self.demandInfl.text()

        if name_checkbox == "c учетом колебания процентной ставки в -10%" and self.demandInfl.isChecked():
            print("---------------------------------------------------")
            ExampleApp_a.thirteen(self)

        name_checkbox = self.InflForec_8.text()

        if name_checkbox == "-5%" and self.InflForec_8.isChecked():
            print("++++++++++++++++++++++++++++++++")
            ExampleApp_a.ras(self,self.PP95)

        name_checkbox = self.demandInfl_2.text()

        if name_checkbox == "-6%" and self.demandInfl_2.isChecked():
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`")
            ExampleApp_a.ras(self,self.PP94)

        name_checkbox = self.demandInfl_9.text()

        if name_checkbox == "+3%" and self.demandInfl_9.isChecked():
            print("---------------------------------------------------")
            ExampleApp_a.ras(self,self.PP103)

        name_checkbox = self.demandInfl_4.text()

        if name_checkbox == "-8%" and self.demandInfl_4.isChecked():
            print("++++++++++++++++++++++++++++++++")
            ExampleApp_a.ras(self,self.PP92)

        name_checkbox = self.demandInfl_12.text()

        if name_checkbox == "+6%" and self.demandInfl_12.isChecked():
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`")
            ExampleApp_a.ras(self,self.PP106)

        name_checkbox = self.demandInfl_8.text()

        if name_checkbox == "+2%" and self.demandInfl_8.isChecked():
            print("---------------------------------------------------")
            ExampleApp_a.ras(self,self.PP102)

        name_checkbox = self.demandInfl_15.text()

        if name_checkbox == "+9%" and self.demandInfl_15.isChecked():
            print("++++++++++++++++++++++++++++++++")
            ExampleApp_a.ras(self,self.PP109)

        name_checkbox = self.demandInfl_11.text()

        if name_checkbox == "+5%" and self.demandInfl_11.isChecked():
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`")
            ExampleApp_a.ras(self,self.PP105)

        name_checkbox = self.demandInfl_5.text()

        if name_checkbox == "-9%" and self.demandInfl_5.isChecked():
            print("---------------------------------------------------")
            ExampleApp_a.ras(self,self.PP91)

        name_checkbox = self.demandInfl_14.text()

        if name_checkbox == "+8%" and self.demandInfl_14.isChecked():
            print("++++++++++++++++++++++++++++++++")
            ExampleApp_a.ras(self,self.PP108)

        name_checkbox = self.demandInfl_10.text()

        if name_checkbox == "+4%" and self.demandInfl_10.isChecked():
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`")
            ExampleApp_a.ras(self,self.PP104)

        name_checkbox = self.demandInfl_13.text()

        if name_checkbox == "+7%" and self.demandInfl_13.isChecked():
            print("---------------------------------------------------")
            ExampleApp_a.ras(self,self.PP107)

        name_checkbox = self.demandInfl_16.text()

        if name_checkbox == "+10%" and self.demandInfl_16.isChecked():
            print("++++++++++++++++++++++++++++++++")
            ExampleApp_a.ras(self,self.PP110)

        name_checkbox = self.demandInfl_6.text()

        if name_checkbox == "+1%" and self.demandInfl_6.isChecked():
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`")
            ExampleApp_a.ras(self,self.PP101)



    def one(self):

        deltaT = 1
        t = 0
        x = 1
        MEP = 0
        print("В этом разделе будут напечатаны результаты прогнозирования без колебаний")
        print("")
        print("Месяц", ',', "Номер месяца", ',', "Значение", ',', "Стоимость производства", ',', "Стоимость перевозок",
              ',', "Месячная прибыль", ',', "Процент по кредиту")
        print("Январь", ',', "0", ',', self.AL, ',', self.LC, ',', self.OC, ',', self.PM, ',',
              round(self.Z * self.AL * x, 2))

        self.tableWidget.setRowCount(self.QRS)
        col = 0
        row = 0
        self.data = []
        self.data.append((((str("Январь")))))
        self.data.append((((str(0)))))
        self.data.append((((str(self.AL)))))
        self.data.append((((str(self.LC)))))
        self.data.append((((str(self.OC)))))
        self.data.append((((str(self.PM)))))
        self.data.append((((str(round(self.Z * self.AL * x, 2))))))
        for item in self.data:
            cellinfo = QTableWidgetItem(item)
            self.tableWidget.setItem(row, col, cellinfo)
            col += 1
        row = 0
        col = 0
        month = ""

        ch = ""
        datas = []

        self.d = []
        self.d1 = []
        self.d2= []
        self.d3 = []
        self.d4 = []
        qwe = []

        while (t < self.QRS):

            S = self.AL + (deltaT * self.Z * self.AL * x) + (deltaT * self.LC) + (deltaT * self.OC) + (deltaT * self.PM)
            t = t + deltaT
            if S < 0:
                x = 1
            if S >= 0:
                x = 0
            if t > 1 and t % 12 == 0:
                S = S + self.ALT
            if t % 12 == 0:
                MEP = 'Январь'
            elif t % 12 == 1:
                MEP = 'Февраль'
            elif t % 12 == 2:
                MEP = 'Март'
            elif t % 12 == 3:
                MEP = 'Апрель'
            elif t % 12 == 4:
                MEP = 'Май'
            elif t % 12 == 5:
                MEP = 'Июнь'
            elif t % 12 == 6:
                MEP = 'Июль'
            elif t % 12 == 7:
                MEP = 'Август'
            elif t % 12 == 8:
                MEP = 'Сентябрь'
            elif t % 12 == 9:
                MEP = 'Октябрь'
            elif t % 12 == 10:
                MEP = 'Ноябрь'
            elif t % 12 == 11:
                MEP = 'Декабрь'
            self.AL = S
            # print(MEP, ',', t, ',', round(S, 2), ',', self.LC, ',', self.OC, ',', self.PM, ',', round(self.Z * self.AL * x, 2))
            col = 0
            self.data = []
            self.data.append((((str(MEP)))))
            self.data.append((((str(t)))))
            self.data.append((((str(round(S, 2))))))
            self.data.append((((str(self.LC)))))
            self.data.append((((str(self.OC)))))
            self.data.append((((str(self.PM)))))
            self.data.append((((str(round(self.Z * self.AL * x, 2))))))
            print(self.data)
            for item in self.data:
                cellinfo = QTableWidgetItem(item)
                self.tableWidget.setItem(row+1, col, cellinfo)
                col += 1

            row += 1
            month+=((((str(MEP)))))
            ch+= str(round(S, 2)) + ","
            datas.append(((((str(MEP))))))
            self.d.append(round(S, 2))
            self.d1.append(self.LC)
            self.d2.append((self.OC))
            self.d3.append(str(self.PM))
            self.d4.append(str(round(self.Z * self.AL * x, 2)))

            qwe.append(str(round(self.Z * self.AL * x, 2)))
            continue
        ''' plot some random stuff '''
        # random data

        name_checkbox = self.InflForec_9.text()

        if name_checkbox == "значению" and self.InflForec_9.isChecked():
            ExampleApp_a.diag(self,self.d)

        name_checkbox = self.InflForec_11.text()

        if name_checkbox == "производству" and self.InflForec_11.isChecked():
            ExampleApp_a.diag(self, self.d1)

        name_checkbox = self.InflForec_12.text()

        if name_checkbox == "перевозке" and self.InflForec_12.isChecked():
            ExampleApp_a.diag(self, self.d2)

        name_checkbox = self.InflForec_13.text()

        if name_checkbox == "прибыли" and self.InflForec_13.isChecked():
            ExampleApp_a.diag(self, self.d3)

        name_checkbox = self.InflForec_14.text()

        if name_checkbox == "процентам" and self.InflForec_14.isChecked():
            ExampleApp_a.diag(self, self.d4)

    def two(self):

        deltaT = 1
        t = 0
        x = 1
        MEP = 0
        self.tableWidget.setRowCount(self.QRS)
        col = 0
        row = 0
        self.data = []
        self.data.append((((str("Январь")))))
        self.data.append((((str(0)))))
        self.data.append((((str(self.AL)))))
        self.data.append((((str(self.LC)))))
        self.data.append((((str(self.OC)))))
        self.data.append((((str(self.PM)))))
        self.data.append((((str(round(self.Z * self.AL * x, 2))))))
        for item in self.data:
            cellinfo = QTableWidgetItem(item)
            self.tableWidget.setItem(row, col, cellinfo)
            col += 1
        row = 0
        col = 0
        self.d = []
        self.d1 = []
        self.d2 = []
        self.d3 = []
        self.d4 = []
        while (t < self.QRS):
            S = self.AL + (deltaT * self.Z * self.AL * x) + (deltaT * self.LC) + (deltaT * self.OC) + (deltaT * self.PM)
            t = t + deltaT
            if S < 0:
                x = 1
            if S >= 0:
                x = 0
            if t > 1 and t % 12 == 0:
                S = S + (self.ALT + (self.ALT * self.IF))
            if t % 12 == 0:
                MEP = 'Январь'
            elif t % 12 == 1:
                MEP = 'Февраль'
            elif t % 12 == 2:
                MEP = 'Март'
            elif t % 12 == 3:
                MEP = 'Апрель'
            elif t % 12 == 4:
                MEP = 'Май'
            elif t % 12 == 5:
                MEP = 'Июнь'
            elif t % 12 == 6:
                MEP = 'Июль'
            elif t % 12 == 7:
                MEP = 'Август'
            elif t % 12 == 8:
                MEP = 'Сентябрь'
            elif t % 12 == 9:
                MEP = 'Октябрь'
            elif t % 12 == 10:
                MEP = 'Ноябрь'
            elif t % 12 == 11:
                MEP = 'Декабрь'
            self.AL = S
            # print(MEP, ',', t, ',', round(S, 2), ',', self.LC, ',', self.OC, ',', self.PM, ',', round(self.Z * self.AL * x, 2))
            self.data = []
            self.data.append((((str(MEP)))))
            self.data.append((((str(t)))))
            self.data.append((((str(round(S, 2))))))
            self.data.append((((str(self.LC)))))
            self.data.append((((str(self.OC)))))
            self.data.append((((str(self.PM)))))
            self.data.append((((str(round(self.Z * self.AL * x, 2))))))

            for item in self.data:
                cellinfo = QTableWidgetItem(item)
                self.tableWidget.setItem(row+1, col, cellinfo)
                col += 1
            self.d.append(round(S, 2))
            self.d1.append(self.LC)
            self.d2.append((self.OC))
            self.d3.append(str(self.PM))
            self.d4.append(str(round(self.Z * self.AL * x, 2)))
            continue

        name_checkbox = self.InflForec_9.text()

        if name_checkbox == "значению" and self.InflForec_9.isChecked():
            ExampleApp_a.diag(self, self.d)

        name_checkbox = self.InflForec_11.text()

        if name_checkbox == "производству" and self.InflForec_11.isChecked():
            ExampleApp_a.diag(self, self.d1)

        name_checkbox = self.InflForec_12.text()

        if name_checkbox == "перевозке" and self.InflForec_12.isChecked():
            ExampleApp_a.diag(self, self.d2)

        name_checkbox = self.InflForec_13.text()

        if name_checkbox == "прибыли" and self.InflForec_13.isChecked():
            ExampleApp_a.diag(self, self.d3)

        name_checkbox = self.InflForec_14.text()

        if name_checkbox == "процентам" and self.InflForec_14.isChecked():
            ExampleApp_a.diag(self, self.d4)

    def three(self):

        deltaT = 1
        t = 0
        x = 1
        MEP = 0
        self.tableWidget.setRowCount(self.QRS)
        col = 0
        row = 0
        # print("Январь", ',', "0", ',', AL, ',', LC, ',', OC, ',', PM90, ',', round(Z * AL * x, 2))
        self.data = []
        self.data.append((((str("Январь")))))
        self.data.append((((str(0)))))
        self.data.append((((str(self.AL)))))
        self.data.append((((str(self.LC)))))
        self.data.append((((str(self.OC)))))
        self.data.append((((str(self.PM90)))))
        self.data.append((((str(round(self.Z * self.AL * x, 2))))))
        for item in self.data:
            cellinfo = QTableWidgetItem(item)
            self.tableWidget.setItem(row, col, cellinfo)
            col += 1
        row = 0
        col = 0

        self.d = []
        self.d1 = []
        self.d2 = []
        self.d3 = []
        self.d4 = []
        while (t < self.QRS):
            S = self.AL + (deltaT * self.Z * self.AL * x) + (deltaT * self.LC) + (deltaT * self.OC) + (deltaT * self.PM90)
            t = t + deltaT
            if S < 0:
                x = 1
            if S >= 0:
                x = 0
            if t > 1 and t % 12 == 0:
                S = S + (self.ALT + (self.ALT * self.IF))
            if t % 12 == 0:
                MEP = 'Январь'
            elif t % 12 == 1:
                MEP = 'Февраль'
            elif t % 12 == 2:
                MEP = 'Март'
            elif t % 12 == 3:
                MEP = 'Апрель'
            elif t % 12 == 4:
                MEP = 'Май'
            elif t % 12 == 5:
                MEP = 'Июнь'
            elif t % 12 == 6:
                MEP = 'Июль'
            elif t % 12 == 7:
                MEP = 'Август'
            elif t % 12 == 8:
                MEP = 'Сентябрь'
            elif t % 12 == 9:
                MEP = 'Октябрь'
            elif t % 12 == 10:
                MEP = 'Ноябрь'
            elif t % 12 == 11:
                MEP = 'Декабрь'
            self.AL = S
            print(MEP, ',', t, ',', round(S, 2), ',', self.LC, ',', self.OC, ',', self.PM90, ',', round(self.Z * self.AL * x, 2))
            self.data = []
            self.data.append((((str(MEP)))))
            self.data.append((((str(t)))))
            self.data.append(((str(round(S, 2)))))
            self.data.append((((str(self.LC)))))
            self.data.append((((str(self.OC)))))
            self.data.append((((str(self.PM90)))))
            self.data.append((((str(round(self.Z * self.AL * x, 2))))))
            print(self.data)
            for item in self.data:
                cellinfo = QTableWidgetItem(item)
                self.tableWidget.setItem(row+1, col, cellinfo)
                col += 1

            self.d.append(round(S, 2))
            self.d1.append(self.LC)
            self.d2.append((self.OC))
            self.d3.append(str(self.PM90))
            self.d4.append(str(round(self.Z * self.AL * x, 2)))
            continue

        name_checkbox = self.InflForec_9.text()

        if name_checkbox == "значению" and self.InflForec_9.isChecked():
            ExampleApp_a.diag(self, self.d)

        name_checkbox = self.InflForec_11.text()

        if name_checkbox == "производству" and self.InflForec_11.isChecked():
            ExampleApp_a.diag(self, self.d1)

        name_checkbox = self.InflForec_12.text()

        if name_checkbox == "перевозке" and self.InflForec_12.isChecked():
            ExampleApp_a.diag(self, self.d2)

        name_checkbox = self.InflForec_13.text()

        if name_checkbox == "прибыли" and self.InflForec_13.isChecked():
            ExampleApp_a.diag(self, self.d3)

        name_checkbox = self.InflForec_14.text()

        if name_checkbox == "процентам" and self.InflForec_14.isChecked():
            ExampleApp_a.diag(self, self.d4)

    def four(self):

        deltaT = 1
        t = 0
        x = 1
        MEP = 0
        self.tableWidget.setRowCount(self.QRS)
        col = 0
        row = 0
        # print("Январь", ',', "0", ',', AL, ',', LC, ',', OC, ',', PM90, ',', round(Z * AL * x, 2))
        self.data = []
        self.data.append((((str("Январь")))))
        self.data.append((((str(0)))))
        self.data.append((((str(self.AL)))))
        self.data.append((((str(self.LC)))))
        self.data.append((((str(self.OC)))))
        self.data.append((((str(self.PM)))))
        self.data.append((((str(round(self.Z110 * self.AL * x, 2))))))
        for item in self.data:
            cellinfo = QTableWidgetItem(item)
            self.tableWidget.setItem(row, col, cellinfo)
            col += 1
        row = 0
        col = 0
        self.d = []
        self.d1 = []
        self.d2 = []
        self.d3 = []
        self.d4 = []
        while (t < self.QRS):
            S = self.AL + (deltaT * self.Z110 * self.AL * x) + (deltaT * self.LC) + (deltaT * self.OC) + (deltaT * self.PM)
            t = t + deltaT
            if S < 0:
                x = 1
            if S >= 0:
                x = 0
            if t > 1 and t % 12 == 0:
                S = S + (self.ALT + (self.ALT * self.IF))
            if t % 12 == 0:
                MEP = 'Январь'
            elif t % 12 == 1:
                MEP = 'Февраль'
            elif t % 12 == 2:
                MEP = 'Март'
            elif t % 12 == 3:
                MEP = 'Апрель'
            elif t % 12 == 4:
                MEP = 'Май'
            elif t % 12 == 5:
                MEP = 'Июнь'
            elif t % 12 == 6:
                MEP = 'Июль'
            elif t % 12 == 7:
                MEP = 'Август'
            elif t % 12 == 8:
                MEP = 'Сентябрь'
            elif t % 12 == 9:
                MEP = 'Октябрь'
            elif t % 12 == 10:
                MEP = 'Ноябрь'
            elif t % 12 == 11:
                MEP = 'Декабрь'
            self.AL = S
            # print(MEP, ',', t, ',', round(S, 2), ',', LC, ',', OC, ',', PM, ',', round(Z110 * AL * x, 2))


            # print(MEP, ',', t, ',', round(S, 2), ',', self.LC, ',', self.OC, ',', self.PM90, ',', round(self.Z * self.AL * x, 2))
            self.data = []
            self.data.append((((str(MEP)))))
            self.data.append((((str(t)))))
            self.data.append(((str(round(S, 2)))))
            self.data.append((((str(self.LC)))))
            self.data.append((((str(self.OC)))))
            self.data.append((((str(self.PM)))))
            self.data.append((((str(round(self.Z110 * self.AL * x, 2))))))
            for item in self.data:
                cellinfo = QTableWidgetItem(item)
                self.tableWidget.setItem(row+1, col, cellinfo)
                col += 1

            self.d.append(round(S, 2))
            self.d1.append(self.LC)
            self.d2.append((self.OC))
            self.d3.append(str(self.PM))
            self.d4.append(str(round(self.Z110 * self.AL * x, 2)))
            continue
        name_checkbox = self.InflForec_9.text()

        if name_checkbox == "значению" and self.InflForec_9.isChecked():
            ExampleApp_a.diag(self, self.d)

        name_checkbox = self.InflForec_11.text()

        if name_checkbox == "производству" and self.InflForec_11.isChecked():
            ExampleApp_a.diag(self, self.d1)

        name_checkbox = self.InflForec_12.text()

        if name_checkbox == "перевозке" and self.InflForec_12.isChecked():
            ExampleApp_a.diag(self, self.d2)

        name_checkbox = self.InflForec_13.text()

        if name_checkbox == "прибыли" and self.InflForec_13.isChecked():
            ExampleApp_a.diag(self, self.d3)

        name_checkbox = self.InflForec_14.text()

        if name_checkbox == "процентам" and self.InflForec_14.isChecked():
            ExampleApp_a.diag(self, self.d4)

    def five(self):

        deltaT = 1
        t = 0
        x = 1
        MEP = 0
        self.tableWidget.setRowCount(self.QRS)
        col = 0
        row = 0
        # print("Январь", ',', "0", ',', AL, ',', LC, ',', OC, ',', PM90, ',', round(Z * AL * x, 2))
        self.data = []
        self.data.append((((str("Январь")))))
        self.data.append((((str(0)))))
        self.data.append((((str(self.AL90)))))
        self.data.append((((str(self.LC)))))
        self.data.append((((str(self.OC)))))
        self.data.append((((str(self.PM)))))
        self.data.append((((str(round(self.Z * self.AL90 * x, 2))))))
        for item in self.data:
            cellinfo = QTableWidgetItem(item)
            self.tableWidget.setItem(row, col, cellinfo)
            col += 1
        row = 0
        col = 0

        # print("Январь", ',', "0", ',', AL90, ',', LC, ',', OC, ',', PM, ',', round(Z * AL90 * x, 2))

        self.d = []
        self.d1 = []
        self.d2 = []
        self.d3 = []
        self.d4 = []
        while (t < self.QRS):
            S = self.AL + (deltaT * self.Z * self.AL90 * x) + (deltaT * self.LC) + (deltaT * self.OC) + (deltaT * self.PM)
            t = t + deltaT
            if S < 0:
                x = 1
            if S >= 0:
                x = 0
            if t > 1 and t % 12 == 0:
                S = S + (self.ALT90 + (self.ALT90 * self.IF))
            if t % 12 == 0:
                MEP = 'Январь'
            elif t % 12 == 1:
                MEP = 'Февраль'
            elif t % 12 == 2:
                MEP = 'Март'
            elif t % 12 == 3:
                MEP = 'Апрель'
            elif t % 12 == 4:
                MEP = 'Май'
            elif t % 12 == 5:
                MEP = 'Июнь'
            elif t % 12 == 6:
                MEP = 'Июль'
            elif t % 12 == 7:
                MEP = 'Август'
            elif t % 12 == 8:
                MEP = 'Сентябрь'
            elif t % 12 == 9:
                MEP = 'Октябрь'
            elif t % 12 == 10:
                MEP = 'Ноябрь'
            elif t % 12 == 11:
                MEP = 'Декабрь'
            self.AL90 = S
            # print(MEP, ',', t, ',', round(S, 2), ',', LC, ',', OC, ',', PM, ',', round(Z * AL90 * x, 2))


            # print(MEP, ',', t, ',', round(S, 2), ',', self.LC, ',', self.OC, ',', self.PM90, ',', round(self.Z * self.AL * x, 2))

            self.data = []
            self.data.append((((str(MEP)))))
            self.data.append((((str(t)))))
            self.data.append(((str(round(S, 2)))))
            self.data.append((((str(self.LC)))))
            self.data.append((((str(self.OC)))))
            self.data.append((((str(self.PM)))))
            self.data.append((((str(round(self.Z * self.AL90 * x, 2))))))
            for item in self.data:
                cellinfo = QTableWidgetItem(item)
                self.tableWidget.setItem(row+1, col, cellinfo)
                col += 1

            self.d.append(round(S, 2))
            self.d1.append(self.LC)
            self.d2.append((self.OC))
            self.d3.append(str(self.PM))
            self.d4.append(str(round(self.Z * self.AL90 * x, 2)))
            continue

        name_checkbox = self.InflForec_9.text()

        if name_checkbox == "значению" and self.InflForec_9.isChecked():
            ExampleApp_a.diag(self, self.d)

        name_checkbox = self.InflForec_11.text()

        if name_checkbox == "производству" and self.InflForec_11.isChecked():
            ExampleApp_a.diag(self, self.d1)

        name_checkbox = self.InflForec_12.text()

        if name_checkbox == "перевозке" and self.InflForec_12.isChecked():
            ExampleApp_a.diag(self, self.d2)

        name_checkbox = self.InflForec_13.text()

        if name_checkbox == "прибыли" and self.InflForec_13.isChecked():
            ExampleApp_a.diag(self, self.d3)

        name_checkbox = self.InflForec_14.text()

        if name_checkbox == "процентам" and self.InflForec_14.isChecked():
            ExampleApp_a.diag(self, self.d4)

    def six(self):

        deltaT = 1
        t = 0
        x = 1
        MEP = 0
        self.tableWidget.setRowCount(self.QRS)
        col = 0
        row = 0
        # print("Январь", ',', "0", ',', AL, ',', LC, ',', OC, ',', PM90, ',', round(Z * AL * x, 2))
        self.data = []
        self.data.append((((str("Январь")))))
        self.data.append((((str(0)))))
        self.data.append((((str(self.AL110)))))
        self.data.append((((str(self.LC)))))
        self.data.append((((str(self.OC)))))
        self.data.append((((str(self.PM)))))
        self.data.append((((str(round(self.Z * self.AL110 * x, 2))))))
        for item in self.data:
            cellinfo = QTableWidgetItem(item)
            self.tableWidget.setItem(row, col, cellinfo)
            col += 1
        row = 0
        col = 0

        # print("Январь", ',', "0", ',', AL110, ',', LC, ',', OC, ',', PM, ',', round(Z * AL110 * x, 2))
        self.d = []
        self.d1 = []
        self.d2 = []
        self.d3 = []
        self.d4 = []
        while (t < self.QRS):
            S = self.AL110 + (deltaT * self.Z * self.AL110 * x) + (deltaT * self.LC) + (deltaT * self.OC) + (deltaT * self.PM)
            t = t + deltaT
            if S < 0:
                x = 1
            if S >= 0:
                x = 0
            if t > 1 and t % 12 == 0:
                S = S + (self.ALT110 + (self.ALT110 * self.IF))
            if t % 12 == 0:
                MEP = 'Январь'
            elif t % 12 == 1:
                MEP = 'Февраль'
            elif t % 12 == 2:
                MEP = 'Март'
            elif t % 12 == 3:
                MEP = 'Апрель'
            elif t % 12 == 4:
                MEP = 'Май'
            elif t % 12 == 5:
                MEP = 'Июнь'
            elif t % 12 == 6:
                MEP = 'Июль'
            elif t % 12 == 7:
                MEP = 'Август'
            elif t % 12 == 8:
                MEP = 'Сентябрь'
            elif t % 12 == 9:
                MEP = 'Октябрь'
            elif t % 12 == 10:
                MEP = 'Ноябрь'
            elif t % 12 == 11:
                MEP = 'Декабрь'
            self.AL110 = S
            # print(MEP, ',', t, ',', round(S, 2), ',', LC, ',', OC, ',', PM, ',', round(Z * AL110 * x, 2))
            # print(MEP, ',', t, ',', round(S, 2), ',', self.LC, ',', self.OC, ',', self.PM90, ',', round(self.Z * self.AL * x, 2))
            self.data = []
            self.data.append((((str(MEP)))))
            self.data.append((((str(t)))))
            self.data.append((((str(round(S, 2))))))
            self.data.append((((str(self.LC)))))
            self.data.append((((str(self.OC)))))
            self.data.append((((str(self.PM)))))
            self.data.append((((str(round(self.Z * self.AL110 * x, 2))))))
            for item in self.data:
                cellinfo = QTableWidgetItem(item)
                self.tableWidget.setItem(row+1, col, cellinfo)
                col += 1

            self.d.append(round(S, 2))
            self.d1.append(self.LC)
            self.d2.append((self.OC))
            self.d3.append(str(self.PM))
            self.d4.append(str(round(self.Z * self.AL110 * x, 2)))
            continue

        name_checkbox = self.InflForec_9.text()

        if name_checkbox == "значению" and self.InflForec_9.isChecked():
            ExampleApp_a.diag(self, self.d)

        name_checkbox = self.InflForec_11.text()

        if name_checkbox == "производству" and self.InflForec_11.isChecked():
            ExampleApp_a.diag(self, self.d1)

        name_checkbox = self.InflForec_12.text()

        if name_checkbox == "перевозке" and self.InflForec_12.isChecked():
            ExampleApp_a.diag(self, self.d2)

        name_checkbox = self.InflForec_13.text()

        if name_checkbox == "прибыли" and self.InflForec_13.isChecked():
            ExampleApp_a.diag(self, self.d3)

        name_checkbox = self.InflForec_14.text()

        if name_checkbox == "процентам" and self.InflForec_14.isChecked():
            ExampleApp_a.diag(self, self.d4)



    def thirteen(self):

        deltaT = 1
        t = 0
        x = 1
        MEP = 0
        self.tableWidget.setRowCount(self.QRS)
        col = 0
        row = 0
        # print("Январь", ',', "0", ',', AL, ',', LC, ',', OC, ',', PM90, ',', round(Z * AL * x, 2))
        self.data = []
        self.data.append((((str("Январь")))))
        self.data.append((((str(0)))))
        self.data.append((((str(self.AL)))))
        self.data.append((((str(self.LC)))))
        self.data.append((((str(self.OC)))))
        self.data.append((((str(self.PM)))))
        self.data.append((((str(round(self.Z90 * self.AL * x, 2))))))
        for item in self.data:
            cellinfo = QTableWidgetItem(item)
            self.tableWidget.setItem(row, col, cellinfo)
            col += 1
        row = 0
        col = 0

        self.d = []
        self.d1 = []
        self.d2 = []
        self.d3 = []
        self.d4 = []
        while (t < self.QRS):
            S = self.AL + (deltaT * self.Z90 * self.AL * x) + (deltaT * self.LC) + (deltaT * self.OC) + (deltaT * self.PM)
            t = t + deltaT
            if S < 0:
                x = 1
            if S >= 0:
                x = 0
            if t > 1 and t % 12 == 0:
                S = S + (self.ALT + (self.ALT * self.IF))
            if t % 12 == 0:
                MEP = 'Январь'
            elif t % 12 == 1:
                MEP = 'Февраль'
            elif t % 12 == 2:
                MEP = 'Март'
            elif t % 12 == 3:
                MEP = 'Апрель'
            elif t % 12 == 4:
                MEP = 'Май'
            elif t % 12 == 5:
                MEP = 'Июнь'
            elif t % 12 == 6:
                MEP = 'Июль'
            elif t % 12 == 7:
                MEP = 'Август'
            elif t % 12 == 8:
                MEP = 'Сентябрь'
            elif t % 12 == 9:
                MEP = 'Октябрь'
            elif t % 12 == 10:
                MEP = 'Ноябрь'
            elif t % 12 == 11:
                MEP = 'Декабрь'
            self.AL = S
            # print(MEP, ',', t, ',', round(S, 2), ',', self.LC, ',', self.OC, ',', self.PM90, ',', round(self.Z * self.AL * x, 2))
            self.data = []
            self.data.append((((str(MEP)))))
            self.data.append((((str(t)))))
            self.data.append((((str(round(S, 2))))))
            self.data.append((((str(self.LC)))))
            self.data.append((((str(self.OC)))))
            self.data.append((((str(self.PM)))))
            self.data.append((((str(round(self.Z90 * self.AL * x, 2))))))
            for item in self.data:
                cellinfo = QTableWidgetItem(item)
                self.tableWidget.setItem(row+1, col, cellinfo)
                col += 1

            self.d.append(round(S, 2))
            self.d1.append(self.LC)
            self.d2.append((self.OC))
            self.d3.append(str(self.PM))
            self.d4.append(str(round(self.Z90 * self.AL * x, 2)))
            continue
        name_checkbox = self.InflForec_9.text()

        if name_checkbox == "значению" and self.InflForec_9.isChecked():
            ExampleApp_a.diag(self, self.d)

        name_checkbox = self.InflForec_11.text()

        if name_checkbox == "производству" and self.InflForec_11.isChecked():
            ExampleApp_a.diag(self, self.d1)

        name_checkbox = self.InflForec_12.text()

        if name_checkbox == "перевозке" and self.InflForec_12.isChecked():
            ExampleApp_a.diag(self, self.d2)

        name_checkbox = self.InflForec_13.text()

        if name_checkbox == "прибыли" and self.InflForec_13.isChecked():
            ExampleApp_a.diag(self, self.d3)

        name_checkbox = self.InflForec_14.text()

        if name_checkbox == "процентам" and self.InflForec_14.isChecked():
            ExampleApp_a.diag(self, self.d4)



    def ras(self, qwe):

        deltaT = 1
        t = 0
        x = 1
        MEP = 0
        self.tableWidget.setRowCount(self.QRS)
        col = 0
        row = 0
        # print("Январь", ',', "0", ',', AL, ',', LC, ',', OC, ',', PM90, ',', round(Z * AL * x, 2))
        self.data = []
        self.data.append((((str("Январь")))))
        self.data.append((((str(0)))))
        self.data.append((((str(self.AL)))))
        self.data.append((((str(self.LC)))))
        self.data.append((((str(self.OC)))))
        self.data.append((((str(qwe)))))
        self.data.append((((str(round(self.Z * self.AL * x, 2))))))
        for item in self.data:
            cellinfo = QTableWidgetItem(item)
            self.tableWidget.setItem(row, col, cellinfo)
            col += 1
        row = 0
        col = 0
        self.d = []
        self.d1 = []
        self.d2 = []
        self.d3 = []
        self.d4 = []

        while (t < self.QRS):
            S = self.AL + (deltaT * self.Z * self.AL * x) + (deltaT * self.LC) + (deltaT * self.OC) + (deltaT * qwe)
            t = t + deltaT
            if S < 0:
                x = 1
            if S >= 0:
                x = 0
            if t > 1 and t % 12 == 0:
                S = S + (self.ALT + (self.ALT * self.IF))
            if t % 12 == 0:
                MEP = 'Январь'
            elif t % 12 == 1:
                MEP = 'Февраль'
            elif t % 12 == 2:
                MEP = 'Март'
            elif t % 12 == 3:
                MEP = 'Апрель'
            elif t % 12 == 4:
                MEP = 'Май'
            elif t % 12 == 5:
                MEP = 'Июнь'
            elif t % 12 == 6:
                MEP = 'Июль'
            elif t % 12 == 7:
                MEP = 'Август'
            elif t % 12 == 8:
                MEP = 'Сентябрь'
            elif t % 12 == 9:
                MEP = 'Октябрь'
            elif t % 12 == 10:
                MEP = 'Ноябрь'
            elif t % 12 == 11:
                MEP = 'Декабрь'
            self.AL = S
            # print(MEP, ',', t, ',', round(S, 2), ',', self.LC, ',', self.OC, ',', self.PP101, ',', round(self.Z * self.AL * x, 2))
            self.data = []
            self.data.append((((str(MEP)))))
            self.data.append((((str(t)))))
            self.data.append((((str(self.AL)))))
            self.data.append((((str(self.LC)))))
            self.data.append((((str(self.OC)))))
            self.data.append((((str(qwe)))))
            self.data.append((((str(round(self.Z * self.AL * x, 2))))))
            for item in self.data:
                cellinfo = QTableWidgetItem(item)
                self.tableWidget.setItem(row+1, col, cellinfo)
                col += 1
            print(self.data)
            self.d.append(round(S, 2))
            self.d1.append(self.LC)
            self.d2.append((self.OC))
            self.d3.append(str(qwe))
            self.d4.append(str(round(self.Z * self.AL * x, 2)))
            continue
        name_checkbox = self.InflForec_9.text()

        if name_checkbox == "значению" and self.InflForec_9.isChecked():
            ExampleApp_a.diag(self, self.d)

        name_checkbox = self.InflForec_11.text()

        if name_checkbox == "производству" and self.InflForec_11.isChecked():
            ExampleApp_a.diag(self, self.d1)

        name_checkbox = self.InflForec_12.text()

        if name_checkbox == "перевозке" and self.InflForec_12.isChecked():
            ExampleApp_a.diag(self, self.d2)

        name_checkbox = self.InflForec_13.text()

        if name_checkbox == "прибыли" and self.InflForec_13.isChecked():
            ExampleApp_a.diag(self, self.d3)

        name_checkbox = self.InflForec_14.text()

        if name_checkbox == "процентам" and self.InflForec_14.isChecked():
            ExampleApp_a.diag(self, self.d4)


    def diag(self,d):
        # instead of ax.hold(False)
        self.figure.clear()

        # create an axis
        ax = self.figure.add_subplot(111)
        # ax2 = self.figure.add_subplot(111, label="2", frame_on=False)

        # discards the old graph
        # ax.hold(False) # deprecated, see above

        # plot data

        ax.plot(d, "*-", color="C0", label=u'Значение')
        ax.set_xlabel("номер месяца", color="C0")
        ax.set_ylabel("значения", color="C0")
        ax.tick_params(axis='x', colors="C0")
        ax.tick_params(axis='y', colors="C0")

        ax.legend(loc='best', frameon=True)

        # refresh canvas
        self.canvas.draw()


def mains():
    app = QtWidgets.QApplication(sys.argv)  # Новый экземпляр QApplication

    window_a = ExampleApp_a()
    window_a.show()
    app.exec_()  # и запускаем приложение

if __name__ == '__main__':  # Если мы запускаем файл напрямую, а не импортируем
    mains()  # то запускаем функцию main()
