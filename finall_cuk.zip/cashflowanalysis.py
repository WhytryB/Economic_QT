# -*- coding: utf-8 -*-

print ("Для нашего проекта будут использоваться следующие значения: Начальный баланс=0, Стоимость производства=7000")
print ("Стоимость перевозки=8000, Месячный спрос=10000, Затраты на сырье=.26")
print ("Цена проданного товара=1.90, Процентная ставка=.1")

S=float(input('Какой первоначальный стартовый баланс? '))
LC=-float(input('Каковы в итоге месячные затраты на производство? '))
OC=-float(input('Каковы в итоге месячные затраты на перевозку? '))
D=float(input('Какой месячный спрос прогнозируется? '))
Y=(D*12)
print('Количество товара, необходимого на один год, равно ',Y)
R=float(input('Какова стоимость сырья за единицу? '))
AL=-D*12*R
ALT=-D*12*R
print('Годовые затраты на сырье равны', AL)
print('Мы возьмем кредит на цели предприятия на сумму $', AL)
P=float(input('Какова цена за проданный товар? '))
PM=D*P
print('Вследствие этого, с тех пор как месячный спрос равен',D,'месячный доход от продаж -',PM)
ir=float(input('Какую процентную ставку по кредиту Вы ожидаете? (пожалуйста, введите десятичное значение)'))
Z=(ir/12)
print('Таким образом, процентная ставка будет равна:',Z)
QRS=float(input('На сколько месяцев Вы бы хотели увидеть прогноз?'))
IF=float(input('Какой ожидается прогноз по инфляции?'))
INF=IF/12
print(INF)

#
#колебания цен - 10%
PM90=PM*.9
PM110=PM*1.1
#
#колебания по процентной ставке - 10%
Z90=Z*.9
Z110=Z*1.1
#
#колебания на цены материала - 10%
AL90=AL*.9
AL110=AL*1.1
ALT90=ALT*.9
ALT110=ALT*1.1
##
#
#Колебания на спрос в 1%
PP99=PM*.99
PP98=PM*.98
PP97=PM*.97
PP96=PM*.96
PP95=PM*.95
PP94=PM*.94
PP93=PM*.93
PP92=PM*.92
PP91=PM*.91
PP90=PM*.9
PP101=PM*1.01
PP102=PM*1.02
PP103=PM*1.03
PP104=PM*1.04
PP105=PM*1.05
PP106=PM*1.06
PP107=PM*1.07
PP108=PM*1.08
PP109=PM*1.09
PP110=PM*1.1

print('______________________')
print('______________________')
print('______________________')
print('______________________')
print('______________________')

deltaT=1
t=0
x=1
MEP=0
print("В этом разделе будут напечатаны результаты прогнозирования без колебаний")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PM,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PM,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PM)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+ALT
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PM,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PM,Z,AL,MEP))
print("")
print("В этом разделе будут напечатаны результаты прогнозирования c учетом инфляции")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PM,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PM,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PM)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PM,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PM,Z,AL,MEP))
print("")
    
print("В этом разделе будут напечатаны результаты прогнозирования c учетом разницы в цене в -10%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Сумма по кредиту")
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PM90,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PM90,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PM90)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PM90,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PM90,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом разницы в цене в +10%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PM110,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PM110,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PM110)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PM110,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PM110,Z,AL,MEP))
print("")
print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебания процентной ставки в -10%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PM,',',round(Z90*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PM,Z90,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z90*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PM)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PM,',',round(Z90*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PM,Z90,AL,MEP))
print("")
print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний процентной ставки в +10%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PM,',',round(Z110*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PM,Z110 ,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z110*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PM)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PM,',',round(Z110*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PM,Z110,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом разницы затрат на материалы в -10%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL90,',',LC,',',OC,',',PM,',',round(Z*AL90*x,2))
def original(S,t,x,deltaT,LC,OC,PM,Z,AL90,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL90*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PM)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT90+(ALT90 *IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL90=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PM,',',round(Z*AL90*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PM,Z,AL90,MEP))
print("")
    
print("В этом разделе будут напечатаны результаты прогнозирования c учетом разницы затрат на материалы в +10%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL110,',',LC,',',OC,',',PM,',',round(Z*AL110*x,2))
def original(S,t,x,deltaT,LC,OC,PM,Z,AL110,MEP):
    while(t<QRS):
        S=AL110+(deltaT*Z*AL110*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PM)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT110+(ALT110*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL110=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PM,',',round(Z*AL110*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PM,Z,AL110,MEP))
print("")
    
print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в -1%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP99,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP99,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP99)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP99,',',round(Z*AL*x,2))
        continue

print(original(S,t,x,deltaT,LC,OC,PP99,Z,AL,MEP))
print("")
    
print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в -2%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP98,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP98,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP98)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP98,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP98,Z,AL,MEP))
print("")
    
print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в -3%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP97,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP97,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP97)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP97,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP97,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в -4%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP96,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP96,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP96)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP96,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP96,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в -5%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP95,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP95,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP95)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP95,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP95,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в -6%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP94,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP94,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP94)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP94,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP94,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в -7%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP93,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP93,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP93)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP93,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP93,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в -8%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP92,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP92,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP92)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP92,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP92,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в -9%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP91,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP91,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP91)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP91,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP91,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в -10%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP90,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP90,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP90)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP90,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP90,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в +1%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP101,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP101,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP101)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP101,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP101,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в +2%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP102,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP102,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP102)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP102,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP102,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в +3%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP103,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP103,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP103)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP103,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP103,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в +4%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP104,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP104,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP104)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP104,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP104,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в +5%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP105,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP105,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP105)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP105,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP105,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в +6%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP106,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP106,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP106)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP106,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP106,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в +7%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP107,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP107,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP107)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP107,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP107,Z,AL,MEP))
print("")
print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в +8%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP108,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP108,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP108)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP108,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP108,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в +9%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP109,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP109,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP109)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP109,',',round(Z*AL*x,2))
        continue
    
print(original(S,t,x,deltaT,LC,OC,PP109,Z,AL,MEP))
print("")

print("В этом разделе будут напечатаны результаты прогнозирования c учетом колебаний запроса в +10%")
print("")
print("Месяц",',',"Номер месяца",',',"Значение",',',"Стоимость производства",',',"Стоимость перевозок",',',"Месячная прибыль",',',"Процент по кредиту")    
print("Январь",',',"0",',',AL,',',LC,',',OC,',',PP110,',',round(Z*AL*x,2))
def original(S,t,x,deltaT,LC,OC,PP110,Z,AL,MEP):
    while(t<QRS):
        S=AL+(deltaT*Z*AL*x)+(deltaT*LC)+(deltaT*OC)+(deltaT*PP110)
        t=t+deltaT
        if S<0:
            x=1
        if S>=0:
            x=0
        if t>1 and t%12==0:
            S=S+(ALT+(ALT*IF)) 
        if t%12==0:
            MEP='Январь'
        elif t%12==1:
            MEP='Февраль'
        elif t%12==2:
            MEP='Март'
        elif t%12==3:
            MEP='Апрель'
        elif t%12==4:
            MEP='Май'
        elif t%12==5:
            MEP='Июнь'
        elif t%12==6:
            MEP='Июль'
        elif t%12==7:
            MEP='Август'
        elif t%12==8:
            MEP='Сентябрь'
        elif t%12==9:
            MEP='Октябрь'
        elif t%12==10:
            MEP='Ноябрь'
        elif t%12==11:
            MEP='Декабрь'
        AL=S
        print(MEP,',',t,',',round(S,2),',',LC,',',OC,',',PP110,',',round(Z*AL*x,2))
        continue
print(original(S,t,x,deltaT,LC,OC,PP110,Z,AL,MEP))
